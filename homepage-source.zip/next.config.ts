import type { NextConfig } from 'next';
const basePath = process.env.NEXT_PUBLIC_BASE_PATH || '';
const nextConfig: NextConfig = {
  output: 'export',
  trailingSlash: true,
  basePath,
  images: { unoptimized: true },
  webpack: (config) => {
    config.module.rules.push({ test: /\.bib$/, type: 'asset/source' });
    return config;
  },
};
export default nextConfig;
